import {
  require_react
} from "./chunk-GFWMZNU4.js";
export default require_react();
//# sourceMappingURL=react.js.map
